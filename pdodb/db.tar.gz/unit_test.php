<?php
include_once('db.php');

$users = array(
	array('name'=>'CHimdi','age'=>'31'),
	array('name'=>'Yafu','age'=>'87'),
	array('name'=>'Marcel','age'=>'12'),
	array('name'=>'Ryan','age'=>'54'),
);


$r = db::insert("`wpromote`.`users`",$users);
list($res,$id,$error) = $r;


/*
$s = "INSERT INTO users (name,age)
	VALUES(:name,:age)
";
*/

db::select()


?>
